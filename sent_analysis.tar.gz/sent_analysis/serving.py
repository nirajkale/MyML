from keras import models
from os import path
from ArgsManager import ArgsManager
from Tokenizer import BlanketTokenizer
import numpy as np

class Serving:

    def __init__(self, model_path, args:ArgsManager):
        self.args = args
        self.pipeline =  BlanketTokenizer(args)
        if path.exists(model_path):
            print('loading model..')
            self.model = models.load_model(filepath = model_path)
            print('model loaded! ready to serve')
        else:
            raise Exception('Model path does not exist')

    def serve_sample(self, sample:str):
        data = self.pipeline.parse_text(sample)
        result = self.model.predict(data, verbose = 0)
        return np.squeeze(result)

    def serve_samples(self, samples:[]):
        data = self.pipeline.parse_texts(samples)
        result = self.model.predict(data, verbose = 0)
        return list(np.squeeze(result))

if __name__ == '__main__':

    args = ArgsManager(use_app_data= True)
    model_path = r'app_data/checkpoints/cnn_model1/03-0.30.hdf5'
    serving = Serving(model_path, args)

    sentences = [
        'My heart filled with joy while eating this dish',
        'having said that, this accident is the worst in the recent history',
        'i dont know if its good or bad',
        'this was both best and worst thing to be happened'
    ]

    print(serving.serve_samples(sentences))
