import json
from Tokenizer import BlanketTokenizer
from ArgsManager import ArgsManager
import numpy as np
from os import path
from keras import layers, models, optimizers, regularizers
from keras.callbacks import TensorBoard, ModelCheckpoint
from TFLogs import TrainValTensorBoard
import os
from model_maker import ModelMaker
from common import shuffle_arrays_in_unison, ensure_dir

def load_dataset(name, split_per= 0.8):
    print('loading processed :', name)
    data = np.load(path.join('processed_data',name, 'x.npy'))
    labels = np.load(path.join('processed_data',name, 'y.npy'))
    data , labels = shuffle_arrays_in_unison([data, labels])
    m = data.shape[0]
    split_index = int(m*0.8)
    x_train, x_test = data[:split_index], data[split_index:]
    y_train, y_test = labels[:split_index], labels[split_index:]
    return (x_train, y_train), (x_test, y_test)

args= ArgsManager(use_app_data= True)

emb_matrix = np.load(path.join(args['active-embedding-lookup-dir'],'emb.npy'))
vocab_size = emb_matrix.shape[0]
print('emb matrix shape:', emb_matrix.shape)

(x_train, y_train), (x_test, y_test) = load_dataset(name = 'twitter', split_per= 0.8)

mm = ModelMaker(args)
# model = mm.rnn(emb_matrix, name= 'rnn_model2')
model = mm.cnn(emb_matrix, name= 'twitter_cnn_v3')

opt = optimizers.adam(lr= 0.0005)
model.compile(optimizer = opt, loss ='binary_crossentropy', metrics = ['acc'])
print(model.summary())

tb_callback = TrainValTensorBoard( ensure_dir('app_data','logs', model.name), write_graph = True)
tb_ckpoints = ModelCheckpoint( filepath = path.join(ensure_dir('app_data','checkpoints', model.name), "{epoch:02d}-{val_loss:.2f}.hdf5"), monitor='val_loss', verbose= 0)

model.fit( x = x_train, y = y_train, 
        batch_size= 64, 
        epochs= 5, 
        callbacks= [tb_callback, tb_ckpoints], 
        validation_data= (x_test, y_test))

model.save( path.join( ensure_dir('app_data','saved_models'), 'model.h5'))

print('evaluating model..')
scores = model.evaluate(x = x_test, y = y_test)
print(scores)
print('done')




