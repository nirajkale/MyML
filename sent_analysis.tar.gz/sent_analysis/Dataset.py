from os import path
import os
import json
import pandas as pd
import numpy as np
import re
from Tokenizer import BlanketTokenizer
from common import shuffle_arrays_in_unison, ensure_dir
from ArgsManager import ArgsManager

def read_imdb_raw():
    #read positive
    basedir= path.join('raw-datasets','imdb')
    data = []
    labels = []

    def read_files(dirname, label = 1):
        for file in os.listdir(dirname):
            f_name = path.join(dirname, file)
            with open(f_name,'r',encoding="utf8") as f:
                data.append(f.read())
                labels.append(label)

    print('reading imdb raw..')
    read_files( path.join(basedir,'train','pos'))
    read_files( path.join(basedir,'train','neg'), label=0)
    read_files( path.join(basedir,'test','pos'))
    read_files( path.join(basedir,'test','neg'), label=0)

    assert(len(data)==len(labels))
    print('total samples collected:', len(data))

    json_str = json.dumps({
        'data':data,
        'labels':labels
    }, indent=4)
    filepath = path.join('processed_data','data_imdb.json')
    with open(filepath,'w') as f:
        f.write(json_str)
    print('done')
    return filepath

def read_twitter_raw():
    print('reading twitter raw..')
    df = pd.read_csv(path.join('raw-datasets', 'twitter.csv'), encoding="cp1252",header= 0)
    labels = list(df.sentiment.apply(lambda s: 1 if s>0 else 0))
    data = list(df.text)
    cleanse = lambda x :' '.join(re.sub("(@[A-Za-z0-9]+)|(\w+:\/\/\S+)"," ",x).split())
    print('cleansing..')
    data = [cleanse(text) for text in data]
    # print(df.head())
    assert(len(data)==len(labels))
    print('total samples collected:', len(data))

    json_str = json.dumps({
        'data':data,
        'labels':labels
    }, indent=4)
    filepath = path.join('processed_data','data_twitter.json')
    with open(filepath,'w') as f:
        f.write(json_str)
    print('done')
    return filepath

def create_dataset(filepath, dataset_name, args):
    print('creating dataset: ',dataset_name)
    data_dict = json.load(open(filepath, 'r'))
    data = data_dict['data']
    labels = np.array(data_dict['labels'])
    print(labels.shape)

    pipeline = BlanketTokenizer(args)
    data = pipeline.parse_texts(data)

    data , labels = shuffle_arrays_in_unison([data, labels])
    print('saving')
    cache_dir = ensure_dir('processed_data', dataset_name)
    np.save(path.join(cache_dir, 'x.npy'), data)
    np.save(path.join(cache_dir, 'y.npy'), labels)
    print('done')

if __name__ == "__main__":
    
    args = ArgsManager(use_app_data= True)
    ensure_dir('processed_data')

    f_imdb =  read_imdb_raw()
    f_twitter = read_twitter_raw()

    create_dataset(f_imdb, 'imdb', args)
    create_dataset(f_twitter, 'twitter', args)



