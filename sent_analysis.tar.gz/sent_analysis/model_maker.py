from ArgsManager import ArgsManager
from keras import models, layers, regularizers

class ModelMaker:

    def __init__(self, args:ArgsManager):
        self.args = args
    
    def rnn(self, emb_matrix, name):
        vocab_size = emb_matrix.shape[0]
        x= layers.Input(shape = (self.args['sequence_size'],), name='input')
        a = layers.Embedding(input_dim = vocab_size, output_dim = 100, weights = [emb_matrix], trainable = True)(x)
        a = layers.LSTM(128, return_sequences = False, name='lstm1', recurrent_dropout = 0.15)(a)
        a = layers.Dense(100, activation='sigmoid',name ='hidden_dense', kernel_regularizer = regularizers.l2(l = 0.03))(a)
        y_hat = layers.Dense(1, activation = 'sigmoid', name='output')(a)
        return models.Model(x,y_hat, name=name)

    def cnn(self, emb_matrix, name):
        vocab_size = emb_matrix.shape[0]
        x= layers.Input(shape = (self.args['sequence_size'],), name='input')
        a = layers.Embedding(input_dim = vocab_size, output_dim = 100, weights = [emb_matrix], trainable = True)(x)
        a = layers.Conv1D(128, 5, activation='relu')(a)
        a = layers.MaxPooling1D(5)(a)
        a = layers.Conv1D(128, 5, activation='relu')(a)
        a = layers.GlobalMaxPool1D()(a)
        a = layers.Dense(100, activation='sigmoid',name ='hidden_dense', kernel_regularizer = regularizers.l2(l = 0.03))(a)
        y_hat = layers.Dense(1, activation = 'sigmoid', name='output')(a)
        return models.Model(x,y_hat, name=name)

    def cnn2(self, emb_matrix, name):
        vocab_size = emb_matrix.shape[0]
        x= layers.Input(shape = (self.args['sequence_size'],), name='input')
        a = layers.Embedding(input_dim = vocab_size, output_dim = 100, weights = [emb_matrix], trainable = True)(x)
        a = layers.Conv1D(128, 3, activation='relu')(a) #228
        a = layers.MaxPooling1D(2)(a) #114
        a = layers.Conv1D(128, 3, activation='relu')(a) #112
        a = layers.MaxPooling1D(2)(a)#56
        a = layers.Conv1D(128, 3, activation='relu')(a) #52
        a = layers.MaxPooling1D(2)(a)#26
        a = layers.Conv1D(128, 3, activation='relu')(a) #24
        a = layers.GlobalMaxPool1D()(a)
        a = layers.Dense(100, activation='sigmoid',name ='hidden_dense', kernel_regularizer = regularizers.l2(l = 0.03))(a)
        y_hat = layers.Dense(1, activation = 'sigmoid', name='output')(a)
        return models.Model(x,y_hat, name=name)

    def cnn_lstm(self, emb_matrix, name):
        vocab_size = emb_matrix.shape[0]
        x= layers.Input(shape = (self.args['sequence_size'],), name='input')
        a = layers.Embedding(input_dim = vocab_size, output_dim = 100, weights = [emb_matrix], trainable = True)(x)
        a = layers.Conv1D(128, 3, activation='relu')(a) #228
        a = layers.MaxPooling1D(2)(a) #114
        a = layers.Conv1D(128, 3, activation='relu')(a) #112
        a = layers.MaxPooling1D(2)(a)#56
        a = layers.Conv1D(128, 3, activation='relu')(a) #52
        a = layers.MaxPooling1D(2)(a)#26
        a = layers.LSTM(128, return_sequences = False, name='lstm1', recurrent_dropout = 0.15)(a)
        a = layers.Dense(100, activation='sigmoid',name ='hidden_dense', kernel_regularizer = regularizers.l2(l = 0.03))(a)
        y_hat = layers.Dense(1, activation = 'sigmoid', name='output')(a)
        return models.Model(x,y_hat, name=name)

    