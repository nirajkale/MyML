from os import path
import numpy as np
import os

def shuffle_arrays_in_unison(arrays):
    '''
    Supports only numpy arrays
    '''
    fixed_length = arrays[0].shape[0]
    for arr in arrays[1:]:
        if arr.shape[0] != fixed_length:
            raise Exception('All the arrays need ti have same length')
    shuffled_indices = np.random.permutation(fixed_length)
    for i in range(len(arrays)):
        arrays[i] = arrays[i][shuffled_indices]
    return arrays

def ensure_dir(*args):
    dirname = path.join(*args)
    if not path.exists(dirname):
        os.makedirs(dirname)
    return dirname