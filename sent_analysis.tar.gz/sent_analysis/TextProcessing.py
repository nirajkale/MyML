#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 10 13:55:49 2019

@author: niraj
"""
from os import path
root_dir = path.dirname(path.dirname(__file__))
import sys
if root_dir not in sys.path:
    sys.path.append(root_dir)
import re
from os import path
from tqdm import tqdm
import pandas as pd
from ArgsManager import ArgsManager
from abc import ABC,abstractmethod
import spacy

def replace_all(text, value, replacement):
    while value in text:
        text = text.replace(value, replacement)
    return text

class TextProcessing(ABC):
    
    @abstractmethod
    def parse_texts(self, texts:[]):
        pass
    
    @abstractmethod
    def parse_text(self, text:str):
        pass

class SimpleProcessing(TextProcessing):
    
    def __init__(self, args:ArgsManager, model=None):
        self.args = args
        self.replacements = {}
        for verb in 'can could will would is was were do does did must might have has had are need'.split(sep=' '):
            self.replacements[verb+' not'] = [verb+'nt',verb+'n\'t']
        self.replacements['is not'] = ['aint','ain\'t']
        self.replacements['it is'] = ['its','it\'s']        
        self.apply_lemma = args['nlp_apply_lemma']
        self.cleanse_string = args['nlp_cleanse_text']
        self.model = None
        print('INFO::', 'Pipeline Lemmatization is set to :',self.apply_lemma)
        print('INFO::', 'Pipeline Cleansing is set to :', self.cleanse_string)
        if self.apply_lemma:
            if model is not None:
                self.model = model
            else:
                print('loading language model:',args['nlp_model_name'])
                self.model = spacy.load(args['nlp_model_name'])
                print('model loaded!')
        
    def parse_text(self, text:str):
        if self.apply_lemma:
            result = []
            for token in self.model(text):
                if 'PRP' not in token.tag_ and len(token.lemma_)>0:
                    result.append(token.lemma_)
                else:
                    result.append(token.text)
            text = ' '.join(result)
        else:
            text = ' '+text+' '
            for replacement, values in self.replacements.items():
                for value in values:
                    value = ' {0} '.format(value)#to make sure its not part of any other word
                    if value in text:
                        # text = text.replace(value, ' '+replacement+' ')
                        text = replace_all(text, value, ' '+replacement+' ')
        if self.cleanse_string:
            text = re.sub('[^a-zA-Z?\s]',' ? ',text)
        text = replace_all(text, '  ', ' ').lstrip().rstrip().lower()
        text = replace_all(text,'? ?','?')
        return text

    # def parse_series(self, df:pd.Series):
    #     for i,text in tqdm(df.iteritems(), total = df.count()):
    #         df.iloc[i] = self.parse_text(text)
    #     return df
    
    def parse_texts(self, texts:[]):
        for i, text in enumerate(texts):
            texts[i] = self.parse_text(text)
        return texts

class ComplexProcessing(TextProcessing):

    
    def __init__(self, args:ArgsManager, model=None, remove_chars:[] = ['?','_', '"','``','-',"''"]):
        if not model:
            print('loading language model:',args['nlp_model_name'],'..')
            self.model = spacy.load(args['nlp_model_name'])
        else:
            print('using existing model')
            self.model = model
        print('loading entity dictionary')
        self.entity_mapping = pm.load_data(path.join('pickles','entity_mapping.pkl'))
        self.entity_keys = list(self.entity_mapping.keys())
        self.entity_values = list(self.entity_mapping.values())
        print('nlp metadata loaded!')
        self.apply_lemma = args['nlp_apply_lemma']
        self.remove_stop_words = args['nlp_remove_stop_words']
        self.remove_chars = remove_chars
        self.remove_entities = args['nlp_simplify_entities']
        #code to take care of incorrect negations
        self.replacements = {}
        for verb in 'can could will would is was were do does did must might have has had are need'.split(sep=' '):
            self.replacements[verb+' not'] = [verb+'nt',verb+'n\'t']
        self.replacements['is not'] = ['aint','ain\'t']
        self.replacements['it is'] = ['its','it\'s']
        
    def __postprocessing__(self, text):
        if self.remove_chars:
            for ch in self.remove_chars:
                text = text.replace(ch,' ')
        text = text.replace('  ',' ')
        return text
    
    def __preprocessing__(self, text):
        for replacement, values in self.replacements.items():
            for value in values:
                value = ' '+value+' '#to make sure its not part of any other word
                if value in text:
                    text = text.replace(value, ' '+replacement+' ')
        return text
        
    def parse_with_entities(self,text:str):
        text = self.__preprocessing__(text)
        doc = self.model(text)
        result = []
        for token in doc:
            if self.remove_stop_words and token.is_stop:
                continue
            if self.apply_lemma and 'PRP' not in token.tag_:
                tk_text = token.lemma_.lower()
            else:
                tk_text = token.text.lstrip().rstrip().lower()
            result.append( tk_text)
        text = ' '.join(result)
        return self.__postprocessing__(text)
    
    def parse_without_entities(self, text:str):
        text = self.__preprocessing__(text)
        doc = self.model(text)
        result = []
        last_entity =None
        last_entity_word = ''
        for tk in doc:
            if self.remove_stop_words and tk.is_stop:
                continue
            tk_text = tk.text.lower().lstrip().rstrip()
            #check for entities
            if tk.ent_iob_=='O':
                if self.apply_lemma and 'PRP' not in tk.tag_ : #spacy does this weird conversion for pro-nouns
                    result.append(tk.lemma_.lower())
                else:
                    result.append(tk_text)
                last_entity =None
                last_entity_word = ''
            elif last_entity == tk.ent_type_:
                last_entity_word +=  tk.text
                continue
            else:
                last_entity_word +=  tk.text
                result.append(self.entity_mapping[tk.ent_type_])
                last_entity = tk.ent_type_
        text = ' '.join(result)
        return self.__postprocessing__(text)
    
    def parse_texts(self, texts:[]):
        result = []
        for text in texts:
            if self.remove_entities:
                result.append(self.parse_without_entities(text))
            else:
                result.append(self.parse_with_entities(text))
        return result
    
    def parse_series(self, df:pd.Series):
        for i,text in df.iteritems():
            if self.remove_entities:
                df.iloc[i] = self.parse_without_entities(text)
            else:
                df.iloc[i] = self.parse_with_entities(text)
        return df
                
if __name__ == '__main__':

    args = ArgsManager('args.json')
    sp = SimplePipeline(args)
    print(sp.parse_texts(['please dont change this ?']))
    print(sp.parse_text('aint doin it pun   kass 123 for rs 123.2 but   he doesnt doesnt isnt arent 123d13f1s3d  . '))
    
    
    
    #df.examples = nlPipeline.parse_series( df.examples)
