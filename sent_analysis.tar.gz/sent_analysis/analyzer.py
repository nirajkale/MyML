# -*- coding: utf-8 -*-
from ArgsManager import ArgsManager
import json
import numpy as np

args= ArgsManager(use_app_data= True)
data_dict = json.load(open(args["processed-data"], 'r'))
data = data_dict['data']
labels = np.array(data_dict['labels'])

label_counts =  np.unique(labels, return_counts = True)
print(label_counts)

seq_dist = [len(sample.split(sep =' ')) for sample in data]
print('max seq:', max(seq_dist))
print('min seq:', min(seq_dist))
print('min avg:', np.average(seq_dist))


